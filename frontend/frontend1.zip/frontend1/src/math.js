// src/math.js
export function add(a, b) {
    return a + b;
  }
  